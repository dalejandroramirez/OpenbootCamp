import logo from './logo.svg';
import './App.css';
import Jokercomponent from './jokerComponent';


function App() {
  return (
    <div className="App">
      <Jokercomponent/>
    </div>
  );
}

export default App;
