import React from 'react';
import Figure from '../pure/figure';


const Figurecomponent = () => {
  return (
    <Figure
    widthFig={"250px"}
    heigthFig={"255px"}
    colorFig={"rgb(0,0,0)"}
    >

    </Figure>
  );
}

export default Figurecomponent;
