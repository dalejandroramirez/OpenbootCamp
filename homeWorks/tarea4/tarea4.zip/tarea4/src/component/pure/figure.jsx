import React ,{useState} from 'react';


const Figure = ({widthFig, heigthFig}) => {
  

  const [colorFig, setColorFig] = useState(`rgb(0,0,0)`);


  function getRandomArbitrary() {
    return (`rgb(${Math.random()*(255)},${Math.random()*(255)}, ${Math.random()*(255)})`);
  }

  function overMouseColor(){
    setColorFig(getRandomArbitrary());
  }



  return (
    <div style={{width:widthFig, height: heigthFig, background:colorFig}} className='figureStyle'
        onMouseOverCapture={overMouseColor}
        onDoubleClick={ ()=>{setColorFig('rgb(0,0,0)')}}
    >
    </div>
  );
}

export default Figure;
