import logo from './logo.svg';
import './App.css';
import Figurecomponent from './component/container/figureComponent';

function App() {
  return (
    <div className="App">
      <Figurecomponent>
        
      </Figurecomponent>
    </div>
  );
}

export default App;
